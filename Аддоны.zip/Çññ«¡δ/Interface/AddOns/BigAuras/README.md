# Alternative for LoseControl 3.3.5 version

## Based on
* BigDebuffs
* LoseControl
* PhotoRobot

#### Advanced settings as opposed to BigDebuffs or LoseControl
* Alpha for frame that showing information for player (if displaying in center)
* More categories for displaying
* Can change priority for spell in category
* Can disable category for frame

#### Install
##### After download from github - rename folder into "BigAuras"

#### demo
1. ![Demo 1](https://s102myt.storage.yandex.net/rdisk/1be7a0524eee8f078a19c7075a1c9683ea8b8aa178ba413a2080b2d273c7b352/5e3e1e52/6ucPu2jOnOnCDqFRGAYTt35lRLS9__ZGQTC1u9ITsUdJIs2i8FfeGFpMvgR_vAkGf6KoQCDxlrYAKDUU8HQ-HQ==?uid=0&filename=scr1_new.jpg&disposition=inline&hash=&limit=0&content_type=image%2Fjpeg&tknv=v2&owner_uid=822561418&fsize=541969&hid=d35074980060f0266fdc447aa2661582&media_type=image&etag=3856acaeda8257cb24f055cb8641041e&rtoken=hDnoaOMufuj9&force_default=no&ycrid=na-d15e104ccf3f4ab85eb2f7eeae06294f-downloader20h&ts=59e075a26b880&s=b3f0fd354938d90eab604603dcde947be4586eb88e7848a760cf334330d693e6&pb=U2FsdGVkX1_dPLS1eobQzd4AMKdO8d3JQYZVa31lE7bCB9_vkBsEOZCXOcwcm0WmBgX9gHvrF-t6x_-4il0-a3uFMp07pP4DEXbZBS0lQYU)
2. ![Demo 2](https://s56myt.storage.yandex.net/rdisk/243de43384fd83115d1bd8b1969b350e4657d64fd0750c5267045f272648db84/5e3e1e77/6ucPu2jOnOnCDqFRGAYTt4vK8AHhG9n67ndfTgs792cSpBogCA3HsvUNP9w6tQkyKm1i7Nbx6oIRCKbaysrx2g==?uid=0&filename=scr2_new.jpg&disposition=inline&hash=&limit=0&content_type=image%2Fjpeg&tknv=v2&owner_uid=822561418&fsize=531226&hid=2a4c8852731d17e8f20c0e3ccfb9700a&media_type=image&etag=57df18bf6986c6c1f855cdaee915562c&rtoken=spMGbnq0GMZE&force_default=no&ycrid=na-15b2bda0cff0eb890721fe8088530a8d-downloader20h&ts=59e075c5b4bc0&s=7ef4e514e4a7cc96802b5cc238e664cb2ea9dd747b5148199584011bdfea94e8&pb=U2FsdGVkX19lQJ8ut8UuFOSs6UeaBcR22fI4U1zWJAW86voILLLcjOiud5MbrdJlhgUNULFPDN1L7wsfVlaMUsHQw1kJK0lMgXJhUlA1EZ4)

###### support me
* https://streamlabs.com/qbjw/tip
